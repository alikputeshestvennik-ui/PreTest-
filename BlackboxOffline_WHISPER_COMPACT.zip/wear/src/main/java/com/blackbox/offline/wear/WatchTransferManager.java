package com.blackbox.offline.wear;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import com.google.android.gms.wearable.ChannelClient;
import com.google.android.gms.wearable.Node;
import com.google.android.gms.wearable.Wearable;
import java.io.File;
import java.io.FileInputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.List;

/**
 * Handles seamless transfer of voice recordings and command events
 * from Galaxy Watch to the companion Android smartphone over Bluetooth/WiFi.
 */
public final class WatchTransferManager {
    public static final String ACTION_TRANSFER_STATUS = "com.blackbox.offline.wear.TRANSFER_STATUS";
    public static final String PATH_AUDIO_STREAM = "/blackbox/audio_stream";
    public static final String PATH_AUDIO_DATA = "/blackbox/audio_data";
    public static final String PATH_TOGGLE = "/blackbox/record_toggle";
    public static final String PATH_QUERY_STATE = "/blackbox/query_state";

    private WatchTransferManager() {}

    public static void sendWavToPhone(Context context, File wavFile) {
        if (wavFile == null || !wavFile.exists() || wavFile.length() < 100) return;

        broadcastStatus(context, "Поиск смартфона...");

        Wearable.getNodeClient(context).getConnectedNodes().addOnSuccessListener(nodes -> {
            if (nodes == null || nodes.isEmpty()) {
                broadcastStatus(context, "Смартфон не подключен");
                return;
            }

            broadcastStatus(context, "Передача на телефон...");

            for (Node node : nodes) {
                // Primary: ChannelClient streaming
                Wearable.getChannelClient(context).openChannel(node.getId(), PATH_AUDIO_STREAM)
                        .addOnSuccessListener(channel -> {
                            new Thread(() -> {
                                try {
                                    OutputStream os = Wearable.getChannelClient(context).getOutputStream(channel).getResult();
                                    try (FileInputStream fis = new FileInputStream(wavFile)) {
                                        byte[] buf = new byte[8192];
                                        int len;
                                        while ((len = fis.read(buf)) != -1) {
                                            os.write(buf, 0, len);
                                        }
                                        os.flush();
                                    }
                                    broadcastStatus(context, "Отправлено на смартфон ✓");
                                } catch (Exception e) {
                                    // Fallback to MessageClient if channel write fails
                                    fallbackSendMessage(context, node.getId(), wavFile);
                                }
                            }).start();
                        })
                        .addOnFailureListener(e -> fallbackSendMessage(context, node.getId(), wavFile));
            }
        }).addOnFailureListener(e -> broadcastStatus(context, "Ошибка связи со смартфоном"));
    }

    private static void fallbackSendMessage(Context context, String nodeId, File wavFile) {
        new Thread(() -> {
            try {
                byte[] data = new byte[(int) wavFile.length()];
                try (FileInputStream fis = new FileInputStream(wavFile)) {
                    int read = fis.read(data);
                    if (read > 0) {
                        Wearable.getMessageClient(context).sendMessage(nodeId, PATH_AUDIO_DATA, data)
                                .addOnSuccessListener(v -> broadcastStatus(context, "Отправлено на смартфон ✓"))
                                .addOnFailureListener(err -> broadcastStatus(context, "Сбой передачи"));
                    }
                }
            } catch (Exception ignored) {}
        }).start();
    }

    public static void togglePhoneRecording(Context context) {
        Wearable.getNodeClient(context).getConnectedNodes().addOnSuccessListener(nodes -> {
            if (nodes != null) {
                for (Node node : nodes) {
                    Wearable.getMessageClient(context).sendMessage(node.getId(), PATH_TOGGLE, new byte[0]);
                }
            }
        });
    }

    public static void queryPhoneState(Context context) {
        Wearable.getNodeClient(context).getConnectedNodes().addOnSuccessListener(nodes -> {
            if (nodes != null) {
                for (Node node : nodes) {
                    Wearable.getMessageClient(context).sendMessage(node.getId(), PATH_QUERY_STATE, new byte[0]);
                }
            }
        });
    }

    private static void broadcastStatus(Context context, String status) {
        Intent intent = new Intent(ACTION_TRANSFER_STATUS);
        intent.putExtra("status", status);
        context.sendBroadcast(intent);
    }
}
