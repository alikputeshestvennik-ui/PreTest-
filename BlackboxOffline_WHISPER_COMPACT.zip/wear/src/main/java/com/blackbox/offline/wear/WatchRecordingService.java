package com.blackbox.offline.wear;

import android.app.*;
import android.content.*;
import android.media.*;
import android.os.*;
import java.io.*;
import java.util.UUID;

/**
 * Foreground Wrist Recording Service for Galaxy Watch.
 * Captures crystal-clear 16 kHz 16-bit mono PCM directly from the watch's microphone,
 * packs into WAV, and transfers to the smartphone for local Whisper STT processing.
 */
public class WatchRecordingService extends Service {
    public static final String ACTION_START = "com.blackbox.offline.wear.START";
    public static final String ACTION_STOP = "com.blackbox.offline.wear.STOP";
    public static final String ACTION_STATE = "com.blackbox.offline.wear.STATE";

    public static volatile boolean isRecording = false;

    private static final int RATE = 16000;
    private static final int FRAME = 1024;
    private AudioRecord mic;
    private Thread worker;
    private PowerManager.WakeLock wakeLock;
    private ByteArrayOutputStream audioBuffer;
    private long startTime;

    @Override
    public void onCreate() {
        super.onCreate();
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel ch = new NotificationChannel("watch_rec", "Blackbox Watch", NotificationManager.IMPORTANCE_LOW);
            getSystemService(NotificationManager.class).createNotificationChannel(ch);
        }
        PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
        if (pm != null) {
            wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "BlackboxWatch:MicLock");
        }
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent != null ? intent.getAction() : "";
        if (ACTION_START.equals(action) && !isRecording) {
            startWatchRecording();
        } else if (ACTION_STOP.equals(action) && isRecording) {
            stopWatchRecording();
        }
        return START_NOT_STICKY;
    }

    private void startWatchRecording() {
        try {
            vibrateWatch(new long[]{0, 80});

            Notification n = new Notification.Builder(this, "watch_rec")
                    .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                    .setContentTitle("Blackbox")
                    .setContentText("Запись с микрофона часов...")
                    .setOngoing(true)
                    .build();

            if (Build.VERSION.SDK_INT >= 29) {
                startForeground(801, n, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE);
            } else {
                startForeground(801, n);
            }

            if (wakeLock != null && !wakeLock.isHeld()) {
                wakeLock.acquire(15 * 60 * 1000L); // 15 min max
            }

            int bufSize = Math.max(AudioRecord.getMinBufferSize(RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT), FRAME * 4);
            mic = new AudioRecord(MediaRecorder.AudioSource.MIC, RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, bufSize);
            mic.startRecording();

            isRecording = true;
            startTime = System.currentTimeMillis();
            audioBuffer = new ByteArrayOutputStream();

            notifyState(true);

            worker = new Thread(this::recordLoop);
            worker.start();
        } catch (Exception e) {
            e.printStackTrace();
            stopWatchRecording();
        }
    }

    private void recordLoop() {
        short[] buf = new short[FRAME];
        while (isRecording && mic != null) {
            int read = mic.read(buf, 0, FRAME);
            if (read > 0 && audioBuffer != null) {
                for (int i = 0; i < read; i++) {
                    audioBuffer.write(buf[i] & 0xFF);
                    audioBuffer.write((buf[i] >> 8) & 0xFF);
                }
            }
        }
    }

    private void stopWatchRecording() {
        isRecording = false;
        vibrateWatch(new long[]{0, 60, 80, 60});

        if (mic != null) {
            try { mic.stop(); } catch (Exception ignored) {}
            mic.release();
            mic = null;
        }

        if (wakeLock != null && wakeLock.isHeld()) {
            wakeLock.release();
        }

        stopForeground(true);
        notifyState(false);

        // Process and transfer audio buffer
        if (audioBuffer != null && audioBuffer.size() > RATE) {
            byte[] pcmData = audioBuffer.toByteArray();
            audioBuffer = null;

            new Thread(() -> {
                try {
                    File cacheDir = new File(getCacheDir(), "watch_clips");
                    cacheDir.mkdirs();
                    File wav = new File(cacheDir, "watch_" + UUID.randomUUID().toString() + ".wav");
                    writeWavFile(wav, pcmData);

                    // Send to companion phone!
                    WatchTransferManager.sendWavToPhone(this, wav);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }).start();
        }

        stopSelf();
    }

    private void writeWavFile(File f, byte[] p) throws Exception {
        try (FileOutputStream o = new FileOutputStream(f)) {
            o.write("RIFF".getBytes());
            le(o, 36 + p.length);
            o.write("WAVEfmt ".getBytes());
            le(o, 16);
            o.write(new byte[]{1, 0, 1, 0});
            le(o, RATE);
            le(o, RATE * 2);
            o.write(new byte[]{2, 0, 16, 0});
            o.write("data".getBytes());
            le(o, p.length);
            o.write(p);
            o.flush();
        }
    }

    private void le(OutputStream o, int n) throws Exception {
        o.write(n);
        o.write(n >> 8);
        o.write(n >> 16);
        o.write(n >> 24);
    }

    private void vibrateWatch(long[] pattern) {
        try {
            Vibrator v = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
            if (v != null && v.hasVibrator()) {
                if (Build.VERSION.SDK_INT >= 26) {
                    v.vibrate(VibrationEffect.createWaveform(pattern, -1));
                } else {
                    v.vibrate(pattern, -1);
                }
            }
        } catch (Throwable ignored) {}
    }

    private void notifyState(boolean active) {
        Intent intent = new Intent(ACTION_STATE);
        intent.putExtra("recording", active);
        sendBroadcast(intent);
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onDestroy() {
        if (isRecording) stopWatchRecording();
        super.onDestroy();
    }
}
