package com.blackbox.rewind;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Build;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.Gravity;
import android.widget.*;
import java.io.File;

public class RewindActivity extends Activity {
    private ImageView logoView;
    private TextView statusView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setBackgroundColor(0xFF000000);
        int pad = (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 24, getResources().getDisplayMetrics());
        root.setPadding(pad, pad, pad, pad);

        TextView title = new TextView(this);
        title.setText("BLACKBOX REWIND");
        title.setTextColor(Color.WHITE);
        title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 20);
        title.setTypeface(Typeface.create("sans-serif-black", Typeface.BOLD));
        title.setLetterSpacing(0.1f);
        root.addView(title);

        TextView sub = new TextView(this);
        sub.setText("Кольцевой буфер памяти (15 минут)");
        sub.setTextColor(0xFF8E95A2);
        sub.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        root.addView(sub);

        logoView = new ImageView(this);
        int logoRes = getResources().getIdentifier("blackbox_mark", "drawable", getPackageName());
        if (logoRes != 0) logoView.setImageResource(logoRes);
        int size = (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 150, getResources().getDisplayMetrics());
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(size, size);
        lp.topMargin = (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 40, getResources().getDisplayMetrics());
        lp.bottomMargin = (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 30, getResources().getDisplayMetrics());
        logoView.setLayoutParams(lp);
        logoView.setOnClickListener(v -> toggleService());
        root.addView(logoView);

        statusView = new TextView(this);
        statusView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        statusView.setTextColor(0xFFFFA25F);
        statusView.setPadding(0, 0, 0, (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 24, getResources().getDisplayMetrics()));
        root.addView(statusView);

        Button save5Btn = new Button(this);
        save5Btn.setText("💾 Сохранить последние 5 минут");
        save5Btn.setOnClickListener(v -> {
            Intent i = new Intent(this, RewindBufferService.class).setAction(RewindBufferService.ACTION_SAVE_CLIP);
            i.putExtra("minutes", 5);
            startService(i);
            Toast.makeText(this, "Фрагмент (5 мин) сохранён в память!", Toast.LENGTH_SHORT).show();
        });
        root.addView(save5Btn);

        setContentView(root);
        updateUi();
    }

    private void toggleService() {
        if (checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{android.Manifest.permission.RECORD_AUDIO}, 11);
            return;
        }

        Intent i = new Intent(this, RewindBufferService.class);
        if (RewindBufferService.isRunning) {
            i.setAction(RewindBufferService.ACTION_STOP);
        } else {
            i.setAction(RewindBufferService.ACTION_START);
        }
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(i); else startService(i);

        logoView.postDelayed(this::updateUi, 250);
    }

    private void updateUi() {
        boolean r = RewindBufferService.isRunning;
        int res = r ? getResources().getIdentifier("blackbox_mark", "drawable", getPackageName())
                    : getResources().getIdentifier("blackbox_mark_mono", "drawable", getPackageName());
        if (res != 0) logoView.setImageResource(res);
        statusView.setText(r ? "● БУФЕР АКТИВЕН (15 МИН)" : "БУФЕР ВЫКЛЮЧЕН");
        statusView.setTextColor(r ? 0xFFEF4444 : 0xFF8E95A2);
    }
}
