package com.blackbox.rewind;

import android.app.*;
import android.content.*;
import android.media.*;
import android.os.*;
import java.io.*;
import java.util.*;

/**
 * High-efficiency 15-Minute Circular Memory Buffer Service.
 * Does not store long-term audio files on disk. Keeps rolling audio in memory.
 * Tap "Save Last 5/15 Minutes" exports permanent clip to disk instantly.
 */
public class RewindBufferService extends Service {
    public static final String ACTION_START = "com.blackbox.rewind.START";
    public static final String ACTION_STOP = "com.blackbox.rewind.STOP";
    public static final String ACTION_SAVE_CLIP = "com.blackbox.rewind.SAVE_CLIP";

    public static volatile boolean isRunning = false;
    private static final int RATE = 16000;
    private static final int FRAME = 1024;
    // 15 minutes rolling buffer: 15 * 60 * 16000 samples * 2 bytes ~= 28.8 MB in memory
    private static final int MAX_BUFFER_BYTES = 15 * 60 * RATE * 2;

    private AudioRecord mic;
    private Thread worker;
    private volatile boolean active = false;

    private final byte[] ringBuffer = new byte[MAX_BUFFER_BYTES];
    private int writeHead = 0;
    private int filledBytes = 0;

    @Override
    public void onCreate() {
        super.onCreate();
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel ch = new NotificationChannel("rewind", "Blackbox Rewind", NotificationManager.IMPORTANCE_LOW);
            ch.setDescription("15-минутный кольцевой буфер");
            getSystemService(NotificationManager.class).createNotificationChannel(ch);
        }
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent != null ? intent.getAction() : "";
        if (ACTION_START.equals(action) && !active) {
            startBuffer();
        } else if (ACTION_STOP.equals(action) && active) {
            stopBuffer();
        } else if (ACTION_SAVE_CLIP.equals(action)) {
            saveCurrentClip(intent.getIntExtra("minutes", 5));
        }
        return START_NOT_STICKY;
    }

    private void startBuffer() {
        try {
            Notification n = new Notification.Builder(this, "rewind")
                    .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                    .setContentTitle("Blackbox Rewind")
                    .setContentText("15-минутный буфер активен. Память не засоряется.")
                    .setOngoing(true)
                    .build();

            if (Build.VERSION.SDK_INT >= 29) {
                startForeground(882, n, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE);
            } else {
                startForeground(882, n);
            }

            int b = Math.max(AudioRecord.getMinBufferSize(RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT), FRAME * 4);
            mic = new AudioRecord(MediaRecorder.AudioSource.MIC, RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, b);
            mic.startRecording();
            active = true;
            isRunning = true;

            worker = new Thread(this::recordLoop);
            worker.start();
        } catch (Exception e) {
            stopBuffer();
        }
    }

    private void recordLoop() {
        byte[] frameBuf = new byte[FRAME * 2];
        while (active && mic != null) {
            int read = mic.read(frameBuf, 0, frameBuf.length);
            if (read > 0) {
                synchronized (ringBuffer) {
                    for (int i = 0; i < read; i++) {
                        ringBuffer[writeHead] = frameBuf[i];
                        writeHead = (writeHead + 1) % MAX_BUFFER_BYTES;
                        if (filledBytes < MAX_BUFFER_BYTES) filledBytes++;
                    }
                }
            }
        }
    }

    private void saveCurrentClip(int minutes) {
        new Thread(() -> {
            try {
                int bytesToSave = Math.min(minutes * 60 * RATE * 2, filledBytes);
                if (bytesToSave < RATE * 2) return;

                byte[] exportedPcm = new byte[bytesToSave];
                synchronized (ringBuffer) {
                    int startPos = (writeHead - bytesToSave + MAX_BUFFER_BYTES) % MAX_BUFFER_BYTES;
                    for (int i = 0; i < bytesToSave; i++) {
                        exportedPcm[i] = ringBuffer[(startPos + i) % MAX_BUFFER_BYTES];
                    }
                }

                File exportDir = new File(getExternalFilesDir(null), "saved_clips");
                exportDir.mkdirs();
                File dest = new File(exportDir, "rewind_" + System.currentTimeMillis() + ".wav");
                writeWav(dest, exportedPcm);
            } catch (Exception ignored) {}
        }).start();
    }

    private void writeWav(File f, byte[] p) throws Exception {
        try (FileOutputStream o = new FileOutputStream(f)) {
            o.write("RIFF".getBytes());
            le(o, 36 + p.length);
            o.write("WAVEfmt ".getBytes());
            le(o, 16);
            o.write(new byte[]{1, 0, 1, 0});
            le(o, RATE);
            le(o, RATE * 2);
            o.write(new byte[]{2, 0, 16, 0});
            o.write("data".getBytes());
            le(o, p.length);
            o.write(p);
            o.flush();
        }
    }

    private void le(OutputStream o, int n) throws Exception {
        o.write(n); o.write(n >> 8); o.write(n >> 16); o.write(n >> 24);
    }

    private void stopBuffer() {
        active = false;
        isRunning = false;
        try {
            if (mic != null) { mic.stop(); mic.release(); mic = null; }
        } catch (Exception ignored) {}
        stopForeground(true);
        stopSelf();
    }

    @Override public IBinder onBind(Intent intent) { return null; }

    @Override
    public void onDestroy() {
        if (active) stopBuffer();
        super.onDestroy();
    }
}
